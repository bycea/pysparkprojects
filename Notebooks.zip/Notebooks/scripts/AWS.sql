-- Databricks notebook source
--CREATION OF DATABASE

-- COMMAND ----------

create database clinicaltrial_db

-- COMMAND ----------

--CREATION OF CLINICAL TRIAL TABLE

-- COMMAND ----------

CREATE EXTERNAL TABLE IF NOT EXISTS `clinicaltrial_db`.`clinicaltrial_2021` (
  `id` string,
  `sponsor` string,
  `status` string,
  `start` string,
  `completion` string,
  `type` string,
  `submissions` string,
  `conditions` string,
  `intervention` string
)
ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe' 
WITH SERDEPROPERTIES (
  'serialization.format' = ',',
  'field.delim' = '|'
) LOCATION 's3://pangolo/ponponn/'
TBLPROPERTIES ('has_encrypted_data'='false', 'skip.header.line.count'='1');

-- COMMAND ----------

--CREATION OF PHARMA TABLE

-- COMMAND ----------

CREATE EXTERNAL TABLE IF NOT EXISTS pharma(
  company string, parent_company string)
  ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'
WITH SERDEPROPERTIES ('field.delim' = ',',
'quoteChar' = '"',
'escapeChar' = '"'
) LOCATION 's3://pharmabuckett/pharmafolder/'
TBLPROPERTIES ('has_encrypted_data'='false', 'skip.header.line.count'='1');


-- COMMAND ----------

--CREATION OF MESH TABLE

-- COMMAND ----------

CREATE EXTERNAL TABLE IF NOT EXISTS mesh(
  term string, tree string)
  ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe' 
WITH SERDEPROPERTIES (
  'serialization.format' = ',',
  'field.delim' = ','
) LOCATION 's3://meshbuckett/meshfolder/'
TBLPROPERTIES ('has_encrypted_data'='false', 'skip.header.line.count'='1');
drop table pharma;

-- COMMAND ----------

--PROBLEM 1

-- COMMAND ----------

select distinct COUNT(*) as number_of_studies from clinicaltrial_2021;

-- COMMAND ----------

--PROBLEM 2

-- COMMAND ----------

select Type, count(*) as count from clinicaltrial_2021 group by Type order by count desc limit 5;

-- COMMAND ----------

--PROBLEM 3

-- COMMAND ----------

select condition,
count(*) as count
from clinicaltrial_2021, UNNEST(SPLIT(conditions, ',')) AS t (condition)
where condition != '' group by condition order by count(*) desc limit 5;

-- COMMAND ----------

--PROBLEM 4

-- COMMAND ----------

create view Condit AS
select Condition
from clinicaltrial_2021
cross join UNNEST(split(Conditions,',')) as t (Condition)
where Condition != ''

-- COMMAND ----------

select substr(mesh.tree,1,3) AS tree,
count(*) as frequency
from mesh
join Condit
on Condit.Condition=mesh.term
group by substr(mesh.tree,1,3)
order by frequency desc
limit 5;

-- COMMAND ----------

--PROBLEM 5

-- COMMAND ----------

select Sponsor,
count(*) as count
from "clinicaltrial_db"."clinicaltrial_2021" where Sponsor not in (select parent_company from "clinicaltrial_db"."pharma")
group by Sponsor order by count(*) desc limit 10;

-- COMMAND ----------

--PROBLEM 6

-- COMMAND ----------

select substring(Completion,1,3) as month, count(Completion) as count
from (select Completion, Status
from clinicaltrial_2021
where status = 'Completed' and substring(Completion,5,8) = '2021')
group by substring(Completion,1,3)
order by case substring(Completion,1,3)
when 'Jan' then 1
when 'Feb' then 2
when 'Mar' then 3
when 'Apr' then 4
when 'May' then 5
when 'Jun' then 6
when 'Jul' then 7
when 'Aug' then 8
when 'Sep' then 9
when 'Oct' then 10
when 'Nov' then 11
when 'Dec' then 12
end;
