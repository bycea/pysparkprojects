-- Databricks notebook source
-- MAGIC %py
-- MAGIC dbutils.fs.ls('/FileStore/tables/mesh.csv')

-- COMMAND ----------

create table if not exists mesh(
term STRING,
tree STRING) using CSV OPTIONS (path = "/FileStore/tables/mesh.csv", delimiter ",",
header = "true");

-- COMMAND ----------

select (*) from mesh;

-- COMMAND ----------

create table if not exists pharma(
company STRING,
parent_company STRING) using CSV OPTIONS (path = "/FileStore/tables/pharma.csv", delimiter ",",
header = "true");

-- COMMAND ----------

select (*) from pharma;

-- COMMAND ----------

create table if not exists clinicaltrial_2021(
id STRING,
sponsor STRING,
status STRING,
start STRING,
completion STRING,
type STRING,
submissions STRING,
conditions STRING,
intervention STRING) using CSV OPTIONS (path = "/FileStore/tables/clinicaltrial_2021.csv", delimiter "|",
header = "true");

-- COMMAND ----------

-- MAGIC %py
-- MAGIC dbutils.fs.ls("/FileStore/tables/clinicaltrial_2021.csv")

-- COMMAND ----------

select * from clinicaltrial_2021;

-- COMMAND ----------

--PROBLEM 1

-- COMMAND ----------

select distinct COUNT(*) as number_of_studies from clinicaltrial_2021;

-- COMMAND ----------

--PROBLEM 2

-- COMMAND ----------

select Type, count(*) as count from clinicaltrial_2021 group by Type order by count desc limit 5;

-- COMMAND ----------

-- PROBLEM 3

-- COMMAND ----------

select Conditions, 
count(*) as count from (select explode(split(Conditions, ',')) as Conditions from clinicaltrial_2021)  
where Conditions is not null group by Conditions order by count(*) desc limit 5;

-- COMMAND ----------

-- PROBLEM 4

-- COMMAND ----------

select * from clinicaltrial_2021 limit 100

-- COMMAND ----------

select * from mesh;

-- COMMAND ----------

create view if not exists splitconditions AS
select explode(split(Conditions, ',')) as Conditions from clinicaltrial_2021;

-- COMMAND ----------

select * from splitconditions;

-- COMMAND ----------

create view if not exists mapped_conditions as
select * from mesh inner join splitconditions on mesh.term = splitconditions.Conditions;

-- COMMAND ----------

select left(tree, 3) as Roots,
count(*) as freq from mapped_conditions 
group by Roots order by count(*) desc limit 5;

-- COMMAND ----------

-- PROBLEM 5

-- COMMAND ----------

select Sponsor,
count(*) as count
from clinicaltrial_2021 where Sponsor not in (select parent_company from pharma) group by Sponsor order by count(*) desc limit 10;

-- COMMAND ----------

-- PROBLEM 6

-- COMMAND ----------

create view if not exists Completed_View as
select left(Completion, 3) as month, substring(Completion, 5, 8) as year, Completion, Status from clinicaltrial_2021 
where (Status = "Completed" and Completion is not null and substring(Completion, 5, 8) = "2021");

-- COMMAND ----------

create view if not exists completedstudies as
select month, count(*) as total_completed from Completed_View group by month
order by case month
when 'Jan' then 1
when 'Feb' then 2
when 'Mar' then 3
when 'Apr' then 4
when 'May' then 5
when 'Jun' then 6
when 'Jul' then 7
when 'Aug' then 8
when 'Sep' then 9
when 'Oct' then 10
when 'Nov' then 11
when 'Dec' then 12
end;

-- COMMAND ----------

select * from completedstudies;

-- COMMAND ----------

-- MAGIC %py
-- MAGIC import matplotlib.pyplot as plt
-- MAGIC import seaborn as sns, numpy as np
-- MAGIC from pylab import *

-- COMMAND ----------

--FURTHER ANALYSIS 1

-- COMMAND ----------

select Conditions, 
count(*) as count from (select explode(split(Conditions, ',')) as Conditions from clinicaltrial_2021)  
where Conditions is not null group by Conditions order by count(*) asc limit 10;

-- COMMAND ----------

--FURTHER ANALYSIS 2

-- COMMAND ----------

create view if not exists unknown_status as
select Status from clinicaltrial_2021 
where (Status = "Unknown status");

-- COMMAND ----------

select count(*) as total from unknown_status;
